# SmartPip AI — Live-data Android project

This Android project wraps a mobile-first scanner in a native Android WebView shell.
It requests OHLC candles from Twelve Data when the user taps **FETCH LIVE DATA & SCAN**.
The user supplies their own Twelve Data API key in Settings; it is stored in local WebView
localStorage on that device. No API key is embedded in the APK.

## Build APK from an Android phone
1. Create a free Twelve Data account and copy your API key: https://twelvedata.com
2. Create a GitHub repository named `SmartPipAI`.
3. Upload the contents of this folder to the repository root (including `.github/workflows`).
4. Open the repository's **Actions** tab. Run **Build SmartPip AI APK** if it did not start automatically.
5. Open the completed workflow run, download artifact `SmartPip-AI-debug-apk`, unzip it, and install `app-debug.apk`.
6. On Android, allow installation from the browser/files app if prompted.

## Data and limitations
- Uses Twelve Data REST `/time_series` data. This is refreshed only when the user taps Scan.
- Provider symbol entitlements vary by account. Free Basic currently lists 8 API credits/minute,
  800 requests/day, real-time forex and crypto; it does not promise every gold/index feed.
- XAU/USD, DJI and IXIC may be unavailable on a free account. If rejected, app displays the provider error.
- API key is stored locally on the phone. Do not share screenshots containing it.
- The scan is a transparent heuristic: 3-candle FVG, 20-bar range break, liquidity sweep/reclaim,
  and a simplified CRT-style sweep/reclaim. It is not machine-learning AI and is not a validated
  trading system. Verify signals and backtest before risking money.
- No broker integration, auto-trading, guaranteed accuracy, or continuous background streaming.
